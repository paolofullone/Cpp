#include <iostream>
#include <locale>

int main()
{
	std::locale::global(std::locale(""));
	system("PAUSE");
	return 0;
}
